@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" amd64
if errorlevel 1 exit /b 1
where cl
cl @"D:\a\_temp\byteorder\Release-amd64-baseline\production.rsp"
if errorlevel 1 exit /b 1
cl @"D:\a\_temp\byteorder\Release-amd64-baseline\probe.rsp"
if errorlevel 1 exit /b 1
link /nologo /OPT:REF /NODEFAULTLIB:stlport_vc71_static.lib production.obj probe.obj /OUT:probe.exe /MAP:probe.map
exit /b %errorlevel%
