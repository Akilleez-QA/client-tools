@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vcvarsall.bat" amd64
if errorlevel 1 exit /b 1
where cl
cl @"C:\pr-byteorder18-results-28d5b41d3\Release-amd64-mutant\production.rsp"
if errorlevel 1 exit /b 1
cl @"C:\pr-byteorder18-results-28d5b41d3\Release-amd64-mutant\probe.rsp"
if errorlevel 1 exit /b 1
link /nologo /OPT:REF /NODEFAULTLIB:stlport_vc71_static.lib production.obj probe.obj /OUT:probe.exe /MAP:probe.map
exit /b %errorlevel%
