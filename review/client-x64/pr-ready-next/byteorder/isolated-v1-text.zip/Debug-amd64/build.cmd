@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vcvarsall.bat" amd64
if errorlevel 1 exit /b 1
where cl
cl @"C:\pr-byteorder18-results-v1\Debug-amd64\production.rsp"
if errorlevel 1 exit /b 1
cl @"C:\pr-byteorder18-results-v1\Debug-amd64\probe.rsp"
if errorlevel 1 exit /b 1
link /nologo /OPT:REF /NODEFAULTLIB:stlport_vc71_static.lib production.obj probe.obj /OUT:probe.exe /MAP:probe.map
exit /b %errorlevel%
