@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul
if errorlevel 1 exit /b %errorlevel%
cl /nologo /EHsc /W4 /Zc:wchar_t- /GR /Gy /showIncludes /MTd /Od /D_DEBUG /DWIN32 /DSOCKET_PROBE_SOCK=0 /DSOCKET_PROBE_UDP=1 /DSOCKET_PROBE_WINSOCK_FIRST=1 /ID:\a\_temp\network-widths\reverted-headers\src /ID:\a\client-tools\client-tools\src /ID:\a\client-tools\client-tools\src\engine\shared\library\sharedNetwork\include\public /ID:\a\client-tools\client-tools\src\external\3rd\library\soePlatform\VChatAPI\utils2.0\utils /ID:\a\client-tools\client-tools\src\external\3rd\library\udplibrary D:\a\client-tools\client-tools\tools\test-windows-network-widths\probe.cpp /FoD:\a\_temp\network-widths\reverted-headers-x86-Debug-s0-u1-w1\case.obj /FeD:\a\_temp\network-widths\reverted-headers-x86-Debug-s0-u1-w1\case.exe /link Ws2_32.lib
exit /b %errorlevel%
