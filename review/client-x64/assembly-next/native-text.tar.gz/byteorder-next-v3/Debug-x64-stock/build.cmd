@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64 >nul
if errorlevel 1 exit /b %errorlevel%
where cl
cl @"C:\byteorder-next-v3\Debug-x64-stock\production.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"C:\byteorder-next-v3\Debug-x64-stock\probe.rsp"
if errorlevel 1 exit /b %errorlevel%
link /nologo /NODEFAULTLIB:stlport_vc71_static.lib "C:\byteorder-next-v3\Debug-x64-stock\production.obj" "C:\byteorder-next-v3\Debug-x64-stock\probe.obj" /OUT:"C:\byteorder-next-v3\Debug-x64-stock\probe.exe" /MAP:"C:\byteorder-next-v3\Debug-x64-stock\probe.map"
exit /b %errorlevel%
