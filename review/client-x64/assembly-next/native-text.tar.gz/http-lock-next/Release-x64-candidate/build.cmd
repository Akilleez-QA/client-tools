@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64 >nul
if errorlevel 1 exit /b %errorlevel%
where cl
cl @"C:\http-lock-next\Release-x64-candidate\production.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"C:\http-lock-next\Release-x64-candidate\probe.rsp"
if errorlevel 1 exit /b %errorlevel%
link /nologo /NODEFAULTLIB:stlport_vc71_static.lib "C:\http-lock-next\Release-x64-candidate\production.obj" "C:\http-lock-next\Release-x64-candidate\probe.obj" /OUT:"C:\http-lock-next\Release-x64-candidate\probe.exe" /MAP:"C:\http-lock-next\Release-x64-candidate\probe.map" kernel32.lib
exit /b %errorlevel%
