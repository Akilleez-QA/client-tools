@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
if errorlevel 1 exit /b %errorlevel%
where cl
cl @"C:\http-lock-next-v2\Debug-Win32-stock\production.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"C:\http-lock-next-v2\Debug-Win32-stock\probe.rsp"
if errorlevel 1 exit /b %errorlevel%
link /nologo /NODEFAULTLIB:stlport_vc71_static.lib "C:\http-lock-next-v2\Debug-Win32-stock\probe.obj" /OUT:"C:\http-lock-next-v2\Debug-Win32-stock\probe.exe" /MAP:"C:\http-lock-next-v2\Debug-Win32-stock\probe.map" kernel32.lib
exit /b %errorlevel%
