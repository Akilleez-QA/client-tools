@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
cl @"C:\byteorder-next-v2\Debug-Win32-candidate\production.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"C:\byteorder-next-v2\Debug-Win32-candidate\probe.rsp"
if errorlevel 1 exit /b %errorlevel%
link /nologo "C:\byteorder-next-v2\Debug-Win32-candidate\production.obj" "C:\byteorder-next-v2\Debug-Win32-candidate\probe.obj" /OUT:"C:\byteorder-next-v2\Debug-Win32-candidate\probe.exe" /MAP:"C:\byteorder-next-v2\Debug-Win32-candidate\probe.map"
exit /b %errorlevel%
