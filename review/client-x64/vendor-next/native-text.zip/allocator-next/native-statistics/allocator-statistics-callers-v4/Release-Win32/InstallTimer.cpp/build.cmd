@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
if errorlevel 1 exit /b %errorlevel%
cl /EHsc /Y- /Gy /Zi /Zc:wchar_t- /MT /O2 /D"WIN32" /D"NDEBUG" /D"_MBCS" /D"DEBUG_LEVEL=0" /D"_CRT_SECURE_NO_DEPRECATE=1" /D"_USE_32BIT_TIME_T=1" /D"_LIB" /D"_MBCS" /I"..\..\..\..\..\..\external\3rd\library\debugHelp" /I"..\..\..\..\..\..\external\3rd\library\stlport453\stlport" /I"..\..\..\..\..\..\external\3rd\library\vtune" /I"..\..\..\sharedFoundation\include\public" /I"..\..\..\sharedFoundationTypes\include\public" /I"..\..\..\sharedMemoryManager\include\public" /I"..\..\include\private" /I"..\..\include\public" /c "C:\allocator-statistics-callers-v4\Release-Win32\InstallTimer.cpp\InstallTimer.cpp" /Fo"C:\allocator-statistics-callers-v4\Release-Win32\InstallTimer.cpp\source.obj" /Fd"C:\allocator-statistics-callers-v4\Release-Win32\InstallTimer.cpp\source.pdb"
exit /b %errorlevel%
