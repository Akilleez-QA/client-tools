@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64 >nul
if errorlevel 1 exit /b %errorlevel%
cl /EHsc /Y- /Gy /Zi /Zc:wchar_t- /MTd /Od /D"WIN32" /D"_DEBUG" /D"_MBCS" /D"DEBUG_LEVEL=2" /D"_CRT_SECURE_NO_DEPRECATE=1" /D"_LIB" /D"_MBCS" /I"C:/SDKs/DXSDK\Include" /I"..\..\..\..\..\..\external\3rd\library\debugHelp" /I"..\..\..\..\..\..\external\3rd\library\stlport453\stlport" /I"..\..\..\..\..\..\external\3rd\library\vtune" /I"..\..\..\sharedFoundation\include\public" /I"..\..\..\sharedFoundationTypes\include\public" /I"..\..\..\sharedMemoryManager\include\public" /I"..\..\include\private" /I"..\..\include\public" /c "C:\allocator-statistics-callers-v4\Debug-x64\InstallTimer.cpp\InstallTimer.cpp" /Fo"C:\allocator-statistics-callers-v4\Debug-x64\InstallTimer.cpp\source.obj" /Fd"C:\allocator-statistics-callers-v4\Debug-x64\InstallTimer.cpp\source.pdb"
exit /b %errorlevel%
