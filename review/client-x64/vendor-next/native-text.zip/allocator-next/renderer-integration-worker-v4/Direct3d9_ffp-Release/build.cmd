@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64 >nul
set DXSDK_DIR=C:\SDKs\DXSDK\
msbuild "C:\renderer-integration-worker-v4\Direct3d9_ffp-Release\Direct3d9_ffp.vcxproj" /t:Build /m:1 /p:Configuration=Release /p:Platform=x64 /p:BuildProjectReferences=true /p:SwgPythonExecutable=C:/ci-dpvs-review/python/python.exe /p:SwgJpegArchive=C:/allocator-next/jpegsrc.v6b.tar.gz /p:SwgClientDepsDir="C:\renderer-integration-worker-v4\deps\Release" /nologo /v:normal
exit /b %errorlevel%
