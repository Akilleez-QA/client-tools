@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
cl @"C:\ui-alignment-readonly-v3\Debug-Win32\compile.rsp"
exit /b %errorlevel%
