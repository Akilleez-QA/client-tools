@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64 >nul
cl @"C:\ui-alignment-readonly-v3\Release-x64\compile.rsp"
exit /b %errorlevel%
