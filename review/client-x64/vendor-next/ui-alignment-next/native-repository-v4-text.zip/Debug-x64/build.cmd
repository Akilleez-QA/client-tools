@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64
if errorlevel 1 exit /b %errorlevel%
cl @"C:/ui-alignment-repo-test-v4/Debug-x64/compile-0.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"C:/ui-alignment-repo-test-v4/Debug-x64/compile-1.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"C:/ui-alignment-repo-test-v4/Debug-x64/compile-2.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"C:/ui-alignment-repo-test-v4/Debug-x64/compile-3.rsp"
if errorlevel 1 exit /b %errorlevel%
link @"C:/ui-alignment-repo-test-v4/Debug-x64/link.rsp"
exit /b %errorlevel%