#include "C:/audio-next/stock-Audio.cpp"
AIL_file_open_callback const audio_open_type = &fileOpenCallBack;
AIL_file_close_callback const audio_close_type = &fileCloseCallBack;
AIL_file_seek_callback const audio_seek_type = &fileSeekCallBack;
AIL_file_read_callback const audio_read_type = &fileReadCallBack;
static_assert(sizeof(UINTa)==sizeof(void*),"Miles file handle width");
static_assert(sizeof(AudioNamespace::FileMap::key_type)==sizeof(UINTa),"file map width");
