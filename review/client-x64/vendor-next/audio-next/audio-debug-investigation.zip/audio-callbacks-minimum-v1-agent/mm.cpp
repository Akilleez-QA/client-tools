#include "C:/allocator-minimum-input/MemoryManager-candidate.h"
#include "C:/allocator-minimum-input/MemoryManager-stats-candidate.cpp"
