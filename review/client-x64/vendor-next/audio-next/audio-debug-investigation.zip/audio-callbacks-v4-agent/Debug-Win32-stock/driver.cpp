#include "C:/audio-next/stock-callbacks.cpp"
#include "sharedFoundation/SetupSharedFoundation.h"
#include "sharedFile/SetupSharedFile.h"
#include "sharedThread/SetupSharedThread.h"
#include "sharedDebug/SetupSharedDebug.h"
#include <cstdio>
#include <cstring>
AIL_file_open_callback const openCallback=&fileOpenCallBack;
AIL_file_close_callback const closeCallback=&fileCloseCallBack;
AIL_file_seek_callback const seekCallback=&fileSeekCallBack;
AIL_file_read_callback const readCallback=&fileReadCallBack;
LONG CALLBACK traceException(EXCEPTION_POINTERS *e) { std::printf("FIRST_EXCEPTION code=%08lx address=%p module=%p\n",e->ExceptionRecord->ExceptionCode,e->ExceptionRecord->ExceptionAddress,GetModuleHandle(0)); return EXCEPTION_CONTINUE_SEARCH; }
int main(int argc,char **argv)
{
 if(argc!=2)return 2;
 std::setvbuf(stdout,0,_IONBF,0);AddVectoredExceptionHandler(1,traceException);std::puts("stage thread");SetupSharedThread::install();std::puts("stage debug");SetupSharedDebug::install(4096);
 SetupSharedFoundation::Data data(SetupSharedFoundation::Data::D_console);
 data.writeMiniDumps=false;data.configFile=0;data.argc=argc;data.argv=argv;
 std::puts("stage foundation");SetupSharedFoundation::install(data);std::puts("stage file");SetupSharedFile::install(false,0);std::puts("stage callbacks");
 unsigned checks=0,failures=0;
#define CHECK(x) do {++checks;if(!(x)){++failures;std::printf("FAIL line %d\n",__LINE__);}}while(0)
 char lowPath[512],highPath[512];std::sprintf(lowPath,"%s/low.bin",argv[1]);std::sprintf(highPath,"%s/high.bin",argv[1]);
 FILE *f=std::fopen(lowPath,"wb");if(!f)return 3;std::fwrite("abcdefgh",8,1,f);std::fclose(f);
 f=std::fopen(highPath,"wb");if(!f)return 3;std::fwrite("ABCDEFGH",8,1,f);std::fclose(f);
 struct HandleOutput { UINTa before,handle,after; } lo={91,0,93},hi={91,0,93};
 s_nextFileHandle=7;CHECK(openCallback(lowPath,&lo.handle)==1);CHECK(lo.handle==7 && lo.before==91 && lo.after==93);
 UINTa const high=sizeof(UINTa)>4?static_cast<UINTa>(0x100000007ui64):8;
 s_nextFileHandle=high;CHECK(openCallback(highPath,&hi.handle)==1);CHECK(hi.handle==high && hi.before==91 && hi.after==93);CHECK(s_fileMap.size()==2);
 char buf[10]={0};CHECK(readCallback(lo.handle,buf,3)==3 && std::memcmp(buf,"abc",3)==0);
 CHECK(readCallback(hi.handle,buf,3)==3 && std::memcmp(buf,"ABC",3)==0);
 CHECK(seekCallback(lo.handle,1,AIL_FILE_SEEK_BEGIN)==1);CHECK(readCallback(lo.handle,buf,2)==2 && std::memcmp(buf,"bc",2)==0);
 CHECK(seekCallback(hi.handle,-1,AIL_FILE_SEEK_CURRENT)==2);CHECK(readCallback(hi.handle,buf,2)==2 && std::memcmp(buf,"CD",2)==0);
 CHECK(seekCallback(hi.handle,-2,AIL_FILE_SEEK_END)==6);CHECK(readCallback(hi.handle,buf,8)==2 && std::memcmp(buf,"GH",2)==0);
 CHECK(readCallback(hi.handle,buf,8)==0);closeCallback(lo.handle);CHECK(s_fileMap.size()==1 && s_fileMap.find(hi.handle)!=s_fileMap.end());closeCallback(hi.handle);CHECK(s_fileMap.empty());
#ifdef _DEBUG
 CHECK(ms_handleNameMap.find(hi.handle)!=ms_handleNameMap.end());CHECK(ms_fileCloseHandleSet.find(hi.handle)!=ms_fileCloseHandleSet.end());
#endif
 char absent[512];std::sprintf(absent,"%s/absent.bin",argv[1]);hi.handle=static_cast<UINTa>(-1);CHECK(openCallback(absent,&hi.handle)==0);CHECK(hi.handle==0 && hi.before==91 && hi.after==93);
 std::puts("stage remove");SetupSharedFoundation::remove();std::printf("checks=%u failures=%u handle_bits=%u\n",checks,failures,unsigned(sizeof(UINTa)*8));return failures?1:0;
}
