@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64
if errorlevel 1 exit /b 1
cl /nologo /MT proxy.c /Feproxy.exe /link /STACK:2097152
