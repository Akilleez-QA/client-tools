@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86
if errorlevel 1 exit /b 1
cl /nologo /DPCRE_STATIC /DSUPPORT_UTF8 /DHAVE_CONFIG_H /DPOSIX_MALLOC_THRESHOLD=10 /MT /IC:\pcre-native-v3\x86-Release\pcre-4.1 C:\regex-count-next\stock-Win32-Release\pcretest.c C:\xml-pcre-next\legacy-libpcre.a /Fepcretest.exe
