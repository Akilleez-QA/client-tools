@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64
if errorlevel 1 exit /b 1
cl /nologo /DPCRE_STATIC /DSUPPORT_UTF8 /DHAVE_CONFIG_H /DPOSIX_MALLOC_THRESHOLD=10 /MTd /IC:\pcre-native-v3\amd64-Debug\pcre-4.1 C:\regex-count-next\candidate-x64-Debug\pcretest.c C:\parser-integration-v3\x64-Debug\pcre.lib /Fepcretest.exe
