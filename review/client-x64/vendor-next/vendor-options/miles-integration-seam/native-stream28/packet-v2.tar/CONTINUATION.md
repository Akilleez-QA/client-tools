POODO_CONTINUATION_V3_0
schema: POODO_CONTINUATION/3.0
capsule_id: PC-nativestream28-1
revision: 1
parent_capsule: null
generated_at: '2026-09-30T14:46:02.819322+00:00'
objective: Prepare eight native-Miles-shaped stream operations under the incomplete parent faithful-x64
  goal; freeze before native approval.
acceptance:
- id: AC-nativestream28-1
  criterion: Minimal typed facade/direct delegates and native gate prepared; portable declaration/example
    objects pass; no VM or runtime.
authority:
  allowed: New native-stream28 source/text, local portable object checks, prospective native driver.
  prohibited: VM staging/native gate until exact root review, vendor/engine/runtime/link, product/frozen
    edits, SDK/binary publication or push.
constraints: Eight owned stream operations only; actual signed scalar/pointer shapes; no borrowed sample
  getter or callbacks.
user_directives: Native64-first plain Miles facade; reuse existing driver, distinguish owned and borrowed
  sample lifetimes; no broad option study or descendants.
current_head: D-nativestream28-1
claims:
- id: O-nativestream28-1
  state: observed
  status: active
  text: Two portable objects compiled first attempt; exactly eight unresolved facade function names; all16
    frozen source entries unchanged.
  source_type: artifact
  locator: evidence-portable-v1/receipt.json; stream-symbols.log
  observed_at: '2026-09-30T14:46:02.819322+00:00'
  freshness: Frozen snapshot only
  evidence_family: EF-nativestream28-portable
  rehydration_status: checked
  supports:
  - AC-nativestream28-1
  limits: Actual SDK/native assertions unrun; no vendor/library/runtime or lifetime effect observed.
evidence_bundles:
- id: E-nativestream28-1
  request: Compile header/type/example objects and inspect unresolved references.
  material_inputs:
  - A-nativestream28-source
  result_or_locator: evidence-portable-v1/
  completeness: complete
  artifacts:
  - A-nativestream28-portable
  supports_claims:
  - O-nativestream28-1
orientations:
- id: OR-nativestream28-1
  text: Eight functions are prepared; borrowed sample and callback integration remain deferred.
  depends_on:
  - O-nativestream28-1
  confidence:
    artifact_identity: high
    test_path: high
    causal_model: medium
    outcome: low
  strongest_rival: H-nativestream28-1
alternatives:
- id: H-nativestream28-1
  status: live
  text: Actual SDK signatures or intended v120 build reject the prepared forwarding.
  discriminator: Parent-approved actual pinned-header AMD64 object compile and eight unresolved imports.
decisions:
- id: D-nativestream28-1
  text: Freeze and hand off; wait for exact root review before any VM work.
  depends_on:
  - O-nativestream28-1
  reversible: true
  reverse_if: Review or later authorized gate exposes a source/type defect.
predictions:
- id: P-nativestream28-native
  kind: prospective
  created_at: '2026-09-30T14:40:36.216595+00:00'
  created_before_observation: true
  observable: Three actual v120 AMD64 COFF objects; exactly eight unresolved real SDK imports.
  acceptance: Pinned sources/header/tools/helpers stable, no link/PE/runtime.
  failure_means: Preserve first failure and stop; no automatic repair/retry of frozen source.
  oracle: A-nativestream28-source
  oracle_version: PLAN and prepared build-native.py
  artifact: A-nativestream28-source
  environment: Future fresh C:/native-stream28, actual v120 AMD64 and possessed pinned7.2a header.
  status: pending
  status_history:
  - pending
  outcome_evidence: []
outcomes: []
contradictions: []
artifacts:
- id: A-nativestream28-source
  locator: source-v1.tar
  identity_method: sha256
  identity: 6055b9c780cdaf90d5ce152989a4f6b5abab6520c364b9bee7425556cb809cd9
  mutable: false
  captured_at: '2026-09-30T14:46:02.819322+00:00'
  role: input
- id: A-nativestream28-portable
  locator: evidence-portable-v1/receipt.json
  identity_method: sha256
  identity: 163b0779e7ca3016c865d62af0f10571122a19fa47200ac07582afaff80eb815
  mutable: false
  captured_at: '2026-09-30T14:46:02.819322+00:00'
  role: evidence
rehydration:
  status: complete
  losses: []
delivery_state: checked
outcome_state: unobserved
highest_justified_claim: Portable public stream declaration/example boundary compiles; actual SDK forwarding
  is authored with native gate pending.
required_runtime_observation: None authorized; actual-header object-only gate pending parent review. Vendor/engine
  streaming runtime outside scope.
who_controls_next_test: Parent /root
next_step: Parent reviews frozen source and chooses whether to authorize the prepared native object-only
  gate.
END_POODO_CONTINUATION_V3_0
