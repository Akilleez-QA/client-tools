"""Freeze authored sample composition only; no compiler, VM or vendor execution."""
from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
base=Path(__file__).resolve().parent
seam=base.parent
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def manifest(directory,pin):
    p=seam/directory/'source-manifest.json'
    if digest(p)!=pin:raise RuntimeError('manifest pin '+directory)
    return json.loads(p.read_text())
live=manifest('pipe-live27','a91c57521828ca3bd94963593d19747a802de7f3da64a6dbe71d37f9f8bb5902')
client=manifest('sample-pipe29','cba0fdbed3f78e020432427bc4bd5e70202a06b9ceecba5a0397511d5944c333')
host=manifest('sample-host29','70d84b2f848bbcc234fc0f7c69dd5f80f0e72effee614d160b539e7623c0a836')
for p in base.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
rows=json.loads((base/'sequence.json').read_text())
if len(rows)!=780 or [r['request'] for r in rows]!=list(range(1,781)):raise RuntimeError('prospective count')
for opcode,count in [(3,257),(7,258),(18,256),(20,0)]:
    if sum(r['opcode']==opcode for r in rows)!=count:raise RuntimeError('prospective operation count')
stage=base/'private-source-v1';stage.mkdir(exist_ok=False)
for name,expected in live.items():
    if name.startswith('pipe-live27/'):continue
    p=seam/'pipe-live27/private-source-v1'/name
    if digest(p)!=expected:raise RuntimeError('live source changed '+name)
    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
patch=seam/'sample-pipe29/patches/01-owned-sample-client.patch'
if digest(patch)!=client['patches/01-owned-sample-client.patch']:raise RuntimeError('client patch changed')
r=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(patch)],cwd=stage,capture_output=True,text=True,timeout=30)
(base/'composition-patch.log').write_text(r.stdout+r.stderr)
if r.returncode:raise RuntimeError('client patch failed; preserve stage')
for name in ['transport-candidate/resource_registry.h','startup-bridge23/backend.h']:
    p=seam/'sample-host29/prepared'/name
    if digest(p)!=host[name]:raise RuntimeError('host overlay changed '+name)
    shutil.copyfile(p,stage/name)
prior=json.loads((seam/'native-sample27/source-manifest.json').read_text())
name='native-sample27/ClientMilesSample.h';p=seam/name
if digest(p)!=prior[name]:raise RuntimeError('public sample header changed')
(stage/name).parent.mkdir(exist_ok=True);shutil.copyfile(p,stage/name)
for p in base.iterdir():
    if p.is_file() and p.suffix in ['.h','.cpp','.py','.md','.json'] and p.name!='source-manifest.json':
        target=stage/'sample-live30'/p.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target)
provenance={'live27_manifest':'a91c57521828ca3bd94963593d19747a802de7f3da64a6dbe71d37f9f8bb5902','client29_manifest':'cba0fdbed3f78e020432427bc4bd5e70202a06b9ceecba5a0397511d5944c333','host29_manifest':'70d84b2f848bbcc234fc0f7c69dd5f80f0e72effee614d160b539e7623c0a836','client_patch':digest(patch)}
(stage/'sample-live30/composition-inputs.json').write_text(json.dumps(provenance,indent=2)+'\n')
entries={str(p.relative_to(stage)):digest(p) for p in sorted(stage.rglob('*')) if p.is_file()}
with (base/'source-manifest.json').open('x') as f:json.dump(entries,f,indent=2);f.write('\n')
with tarfile.open(base/'source-v1.tar','x') as t:
    for name in entries:t.add(stage/name,arcname=name,recursive=False)
    t.add(base/'source-manifest.json',arcname='source-manifest.json',recursive=False)
print(json.dumps({'files':len(entries),'source':digest(base/'source-v1.tar'),'manifest':digest(base/'source-manifest.json')},indent=2))
