#ifndef MILES_COORDINATOR_CANDIDATE_H
#define MILES_COORDINATOR_CANDIDATE_H
#include "../protocol-candidate/miles_wire.h"
#include <map>
#include <vector>
namespace MilesCoordinator {
typedef uint64_t Id;
enum State { Active, Draining, Failed };
enum Action { Ordinary, AcquireLock, ReleaseLock };
enum CallbackKind { CausalReverseIo, Unsolicited };
enum Error { Ok, StaleSession, InvalidIdentity, WrongState, Busy, WrongLease,
             Capacity, Unknown, PendingCallback, ClosingResource };
struct Limits {
    size_t registrations, callbacks, requestResources;
    Id maximumId;
    Limits():registrations(64),callbacks(256),requestResources(16),maximumId(UINT64_MAX) {}
};
struct CallbackId { Id registration, sequence; };
struct Readiness {
    size_t requestPins, callbackPins;
    Id closeFrontier, acknowledgedFrontier;
    bool closing, vendorTerminationUnproven;
};
// Deterministic single-control-thread model. No vendor calls or pointer ownership.
// Input handles require structural validity; genuine registry liveness is checked
// by the central owner before admission. No general nested vendor reentry modeled.
// admissionOrdinal is minted AFTER scheduler selection, not a wire correlation ID.
// Intake replay tracking, deferred queues and fairness are outside this model.
class Coordinator {
public:
    Coordinator(Id incarnation, const Limits &limits=Limits());
    Error admitGame(Id session,Id admissionOrdinal,Id lane,Id lease,Action action,
                    const std::vector<MilesWire::Handle> &resources);
    // Trusted coordinator API; never selected directly by an untrusted wire flag.
    Error admitCleanup(Id session,Id admissionOrdinal,Id lane,Id lease,Action action,
                       const std::vector<MilesWire::Handle> &resources);
    Error completeAdmission(Id session,Id admissionOrdinal); // Observed return, NOT semantic vendor success; return value is carried elsewhere.
    Error registerCallback(Id session,Id registration,const MilesWire::Handle &resource);
    Error admitCallback(Id session,Id registration,CallbackKind kind,Id causalAdmission,
                        CallbackId &out);
    Error acknowledge(Id session,const CallbackId &callback);
    Error beginClose(Id session,Id registration);
    Error readiness(Id session,Id registration,Readiness &out) const;
    Error beginDrain(Id session);
    Error fail(Id session); // Client outcome unknown; pins/callbacks/last lease retained.
    State state() const { return current; }
    Id activeAdmission() const { return admissionOrdinal; }
    Id lease() const { return leaseId; }
    Id leaseOwner() const { return ownerLane; }
    uint32_t leaseDepth() const { return depth; }
private:
    struct Callback { CallbackKind kind; Id cause; bool acknowledged; };
    struct Registration {
        MilesWire::Handle resource;
        Id issued,frontier,closeFrontier;
        bool closing;
        std::map<Id,Callback> callbacks;
        Registration():issued(0),frontier(0),closeFrontier(0),closing(false) {}
    };
    Id incarnation,lastAdmission,lastRegistration,lastLease;
    Limits bounds;
    State current;
    Id admissionOrdinal,admissionLane,admissionLease,ownerLane,leaseId;
    uint32_t depth;
    Action admissionAction;
    std::vector<MilesWire::Handle> pins;
    std::map<Id,Registration> registrations;
    size_t callbackCount;
    Error admit(Id session,Id admissionOrdinal,Id lane,Id lease,Action action,
                const std::vector<MilesWire::Handle> &resources,bool cleanup);
    bool causalPending(Id admissionOrdinal) const;
    Coordinator(const Coordinator &);
    Coordinator &operator=(const Coordinator &);
};
}
#endif
