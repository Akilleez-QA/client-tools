@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86
cl @"C:\capture-poll-candidate-v2\Debug-win32\compile.rsp"
exit /b %errorlevel%
