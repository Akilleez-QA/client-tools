@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
lib /nologo "C:\integration-current-v1\workspace\repo\src\compile\win32\clientUserInterface\Debug\clientUserInterface.lib" /remove:"..\..\..\..\..\..\compile\win32\clientUserInterface\Debug\CuiIoWin.obj" /out:"C:\capture-poll-candidate-v2\Debug-win32\without-cui.lib"
exit /b %errorlevel%
