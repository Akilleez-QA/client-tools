@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86_amd64 >nul
lib /nologo /list "C:\integration-current-v2\workspace\repo\src\compile\x64\clientUserInterface\Release\clientUserInterface.lib"
exit /b %errorlevel%
