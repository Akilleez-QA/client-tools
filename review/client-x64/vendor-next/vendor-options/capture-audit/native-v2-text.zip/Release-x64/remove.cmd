@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86_amd64 >nul
lib /nologo "C:\integration-current-v2\workspace\repo\src\compile\x64\clientUserInterface\Release\clientUserInterface.lib" /remove:"R:\repo\tools\configure-client-x64\..\..\src\compile\x64\clientUserInterface\Release\obj\CuiIoWin.obj" /out:"C:\capture-poll-candidate-v2\Release-x64\without-cui.lib"
exit /b %errorlevel%
