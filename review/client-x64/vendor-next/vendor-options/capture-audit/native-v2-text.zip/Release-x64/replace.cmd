@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86_amd64 >nul
lib /nologo "C:\capture-poll-candidate-v2\Release-x64\without-cui.lib" "C:\capture-poll-candidate-v2\Release-x64\CuiIoWin.obj" /out:"C:\capture-poll-candidate-v2\Release-x64\clientUserInterface.lib"
exit /b %errorlevel%
