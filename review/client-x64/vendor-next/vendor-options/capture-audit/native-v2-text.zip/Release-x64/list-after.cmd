@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86_amd64 >nul
lib /nologo /list "C:\capture-poll-candidate-v2\Release-x64\clientUserInterface.lib"
exit /b %errorlevel%
