@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86_amd64 >nul
lib /nologo "C:\integration-current-v2\workspace\repo\src\compile\x64\clientUserInterface\Debug\clientUserInterface.lib" /remove:"R:\repo\tools\configure-client-x64\..\..\src\compile\x64\clientUserInterface\Debug\obj\CuiIoWin.obj" /out:"C:\capture-poll-candidate-v2\Debug-x64\without-cui.lib"
exit /b %errorlevel%
