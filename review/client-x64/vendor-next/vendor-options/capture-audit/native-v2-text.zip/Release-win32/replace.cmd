@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
lib /nologo "C:\capture-poll-candidate-v2\Release-win32\without-cui.lib" "C:\capture-poll-candidate-v2\Release-win32\CuiIoWin.obj" /out:"C:\capture-poll-candidate-v2\Release-win32\clientUserInterface.lib"
exit /b %errorlevel%
