@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
lib /nologo /list "C:\integration-current-v1\workspace\repo\src\compile\win32\clientUserInterface\Release\clientUserInterface.lib"
exit /b %errorlevel%
