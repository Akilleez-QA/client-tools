@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
cl @"C:\null-realloc-compile-v1\Release-win32\sharedMemoryManager\tracked-guards\compile.rsp"
exit /b %errorlevel%
