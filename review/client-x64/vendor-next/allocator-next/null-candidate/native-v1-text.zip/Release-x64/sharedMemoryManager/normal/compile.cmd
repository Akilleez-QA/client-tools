@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86_amd64 >nul
cl @"C:\null-realloc-compile-v1\Release-x64\sharedMemoryManager\normal\compile.rsp"
exit /b %errorlevel%
