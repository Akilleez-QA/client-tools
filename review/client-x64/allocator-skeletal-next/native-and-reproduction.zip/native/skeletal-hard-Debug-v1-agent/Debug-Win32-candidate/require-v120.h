#if !defined(_MSC_VER) || _MSC_VER != 1800
#error Native VS2013 v120 required
#endif
