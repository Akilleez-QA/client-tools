// Diagnostic inclusion of the complete actual TU; no replacement production symbols.
#include "C:/math-next/candidate-skeletal-kernels.cpp"
#include <xmmintrin.h>
#include <cstdio>
#include <cstring>
#include <stdint.h>
struct __declspec(align(16)) Sources { SourceVertex values[65]; };
struct __declspec(align(16)) OffsetSources { unsigned pad; SourceVertex values[65]; };
struct __declspec(align(16)) Dots { Dot3Vector values[65]; };
struct __declspec(align(16)) OffsetDots { unsigned pad; Dot3Vector values[65]; };
static unsigned hashBytes(void const *p,unsigned n) { unsigned h=2166136261u; unsigned char const *v=(unsigned char const*)p; while(n--) h=(h^*v++)*16777619u; return h; }
static void bits(float &f,unsigned n) { std::memcpy(&f,&n,4); }
int main(int argc,char **argv)
{
 if(argc!=2)return 2; FILE *file=std::fopen(argv[1],"wb");if(!file)return 3;
 unsigned const header[]={0x534b4831,1,2688,1104};if(std::fwrite(header,sizeof(header),1,file)!=1)return 4;
 void (*volatile normalKernel)(fill_vb_work const *) = &_fillVertexBufferHard_sse;
 void (*volatile dotKernel)(fill_vb_work const *) = &_fillDot3VertexBufferHard_sse;
 unsigned const saved=_mm_getcsr(); unsigned failures=0,index=0;
 unsigned const counts[]={0,1,2,7,8,9,65};
 for(unsigned mode=0;mode<16;++mode)for(unsigned category=0;category<3;++category)
 for(unsigned ci=0;ci<7;++ci)for(unsigned alignment=0;alignment<2;++alignment)
 for(unsigned layout=0;layout<2;++layout)for(unsigned dot=0;dot<2;++dot)
 {
  _mm_setcsr(0x1f80);
  Sources a;OffsetSources b;Dots da;OffsetDots db;
  SourceVertex *src=alignment?b.values:a.values;Dot3Vector *dots=alignment?db.values:da.values;
  PoseModelTransform transforms[4];
  for(unsigned t=0;t<4;++t) { transforms[t].makeIdentity();for(unsigned c=0;c<4;++c)for(unsigned r=0;r<3;++r)
   transforms[t].matrix[c][r]=category==0 ? (c==3?float(t*3+r):(r==((c+t)%3)?(t&1?-1.0f:1.0f):0.0f)) : float(int((t*17+c*13+r*7)%31)-15)/8.0f; }
  unsigned const special[]={0,0x80000000,1,0x807fffff,0x00800000,0x7f7fffff,0xff7fffff,0x7f800000,0xff800000,0x7fc12345,0x7fa12345,0x3f800000};
  for(unsigned i=0;i<65;++i) {
   src[i].m_firstTransformData.m_transformIndex=i%4;src[i].m_firstTransformData.m_transformWeight=1;src[i].m_extraTransformDataCount=0;
   float p[9];for(unsigned j=0;j<9;++j) {
    if(category==2)bits(p[j],special[(i+j*7)%12]);
    else if(category==0 && j>=3)p[j]=((i+j)%3==0)?1.0f:0.0f;
    else p[j]=float(int((i*29+j*13)%2001)-1000)/16.0f;
   }
   std::memcpy(&src[i].m_position,p,12);std::memcpy(&src[i].m_normal,p+3,12);std::memcpy(&dots[i].m_dot3Vector,p+6,12);dots[i].m_flipState=i&1?-1.0f:1.0f;
  }
  unsigned const h1=hashBytes(src,sizeof(SourceVertex)*65),h2=hashBytes(dots,sizeof(Dot3Vector)*65),h3=hashBytes(transforms,sizeof(transforms));
  unsigned const count=counts[ci],stride=layout?64:(dot?40:24),offset=layout?32:24,begin=32+alignment*4;
  __declspec(align(16)) unsigned char output[4288];std::memset(output,0xa5,sizeof(output));
  __declspec(align(16)) fill_vb_work work;std::memset(&work,0,sizeof(work));
  work.construct(count,src,dot?dots:0,transforms,stride,output+begin,dot?output+begin+offset:0);
  if((uintptr_t(src)&15)!=alignment*4 || (uintptr_t(output+begin)&15)!=alignment*4 || (uintptr_t(&work)&15) || (uintptr_t(transforms)&15))return 5;
  unsigned const csr=((category<2 && index%2==0)?0u:0x1f80) | ((mode&3)<<13) | ((mode&4)?0x8000:0) | ((mode&8)?0x40:0) | (index%2?0x25:0);
  _mm_setcsr(csr);if(dot)dotKernel(&work);else normalKernel(&work);unsigned const after=_mm_getcsr();_mm_setcsr(0x1f80);
  unsigned failure=after!=csr;
  for(unsigned n=0;n<sizeof(output);++n) {
   bool written=false;if(n>=begin) { unsigned v=(n-begin)/stride,k=(n-begin)%stride;written=v<count && (k<24 || (dot && k>=offset && k<offset+16)); }
   if(!written && output[n]!=0xa5)failure|=2;
  }
  if(h1!=hashBytes(src,sizeof(SourceVertex)*65)||h2!=hashBytes(dots,sizeof(Dot3Vector)*65)||h3!=hashBytes(transforms,sizeof(transforms)))failure|=4;
  if(work.m_sourceVectors!=src+count || work.viter!=output+begin+count*stride || (dot && (work.m_sourceDot3Vectors!=dots+count || work.dot3viter!=output+begin+offset+count*stride)))failure|=8;
  unsigned record[1104]={index++,mode,category,count,alignment,layout,dot,stride,offset,csr,after,h1,h2,h3,failure,0};
  std::memcpy(record+16,output,sizeof(output));
  // Only observable bounds; scratch normal/dot3 registers are implementation details.
  std::memcpy(record+1088,&work.minVector,16);std::memcpy(record+1092,&work.maxVector,16);
  failures+=failure!=0;if(std::fwrite(record,sizeof(record),1,file)!=1)return 6;
 }
 _mm_setcsr(saved);if(std::fclose(file))return 7;std::printf("records=%u contract_failures=%u\n",index,failures);return failures?1:0;
}
