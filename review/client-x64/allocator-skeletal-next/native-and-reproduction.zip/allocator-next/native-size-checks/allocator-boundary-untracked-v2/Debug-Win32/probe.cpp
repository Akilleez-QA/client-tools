#include "MemoryManager-diagnostic.cpp"
#include <stdio.h>
#include <string.h>
static unsigned checks,failures;
#define CHECK(x) do { ++checks; if(!(x)) { ++failures; printf("FAIL line=%d\n",__LINE__); } } while(0)
int main()
{
    MemoryManager::setReportAllocations(false);
    using namespace MemoryManagerNamespace;
    int blockSize=0;
    CHECK(calculateAllocationSize(0,blockSize));
    CHECK(blockSize>0 && blockSize%16==0);
    CHECK(calculateAllocationSize(1,blockSize));
    int oneByteBlock=blockSize;
    CHECK(calculateAllocationSize(15,blockSize));
    CHECK(blockSize>=oneByteBlock);
    size_t const expectedMax = (DO_TRACK || DO_GUARDS) ? (static_cast<size_t>(1)<<30)-1 : static_cast<size_t>(2143289344)-3*cms_blockSize-cms_allocatedBlockSize-2*cms_guardBandSize;
    CHECK(calculateAllocationSize(expectedMax-1,blockSize));
    CHECK(calculateAllocationSize(expectedMax,blockSize));
    CHECK(blockSize%16==0);
    CHECK(static_cast<unsigned __int64>(blockSize)+3*cms_blockSize+cms_systemAllocationRoundSize-1<=INT_MAX);
    CHECK(!calculateAllocationSize(expectedMax+1,blockSize));
    CHECK(!calculateAllocationSize(static_cast<size_t>(INT_MAX),blockSize));
    CHECK(!calculateAllocationSize(static_cast<size_t>(-1),blockSize));
    void *p=MemoryManager::allocate(64,123,false,true);
    memset(p,0x5a,64);
    FatalSetThrowExceptions(true);
    int const regions=ms_numberOfSystemAllocations;
    for(int test=0;test<4;++test) {
        bool caught=false;
        try {
            if(test==0) MemoryManager::allocate(expectedMax+1,123,false,true);
            if(test==1) MemoryManager::allocate(static_cast<size_t>(-1),123,false,true);
            if(test==2) MemoryManager::reallocate(p,expectedMax+1);
            if(test==3) convertBytesToMegabytesForSystemAllocation(INT_MAX);
        } catch(FatalException const &e) {
            char const *message=e.getMessage();
            caught=strstr(message,test==3 ? "system allocation size exceeds signed-int range" : "exceeds memory manager range")!=0;
            printf("REJECTION %d %s\n",test,message); fflush(stdout);
        } catch(...) { caught=false; }
        CHECK(caught);
        CHECK(ms_numberOfSystemAllocations==regions);
    }
    bool preserved=true;for(int i=0;i<64;++i) if(static_cast<byte *>(p)[i]!=0x5a) preserved=false;
    CHECK(preserved);
    MemoryManager::free(p,false);
    FatalSetThrowExceptions(false);
    printf("checks=%u failures=%u expected=21\n",checks,failures);fflush(stdout);
    return failures || checks!=21;
}
