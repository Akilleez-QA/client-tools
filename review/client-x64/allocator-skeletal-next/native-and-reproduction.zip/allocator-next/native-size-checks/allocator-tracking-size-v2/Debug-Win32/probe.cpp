// Diagnostic-only amalgamation: generated copy differs ONLY in five feature defines.
// Link real dependency closure; do not also compile MemoryManager.cpp separately.
#include "MemoryManager-diagnostic.cpp"
#include <stdio.h>
#include <string.h>
#if DO_TRACK != 5 || !DO_SCALAR || !DO_GUARDS || !DO_INITIALIZE_FILLS || !DO_FREE_FILLS
#error Tracking fixture requires all real allocator instrumentation paths.
#endif
#if _MSC_VER != 1800
#error This fixture requires native MSVC v120.
#endif
static unsigned checks, failures;
#define CHECK(x) do { ++checks; if (!(x)) { ++failures; printf("FAIL line=%d\n", __LINE__); } } while(0)
static MemoryManagerNamespace::AllocatedBlock *block(void *p)
{
    return reinterpret_cast<MemoryManagerNamespace::AllocatedBlock *>(static_cast<byte *>(p) -
        (MemoryManagerNamespace::cms_allocatedBlockSize + MemoryManagerNamespace::cms_guardBandSize));
}
static bool contents(void *p, size_t n, unsigned char value)
{
    for(size_t i=0;i<n;++i) if(static_cast<unsigned char *>(p)[i]!=value) return false;
    return true;
}
static LONG WINAPI crashRecord(EXCEPTION_POINTERS *e)
{
    MEMORY_BASIC_INFORMATION info; VirtualQuery(e->ExceptionRecord->ExceptionAddress,&info,sizeof(info));
    printf("FAULT code=%08lx address=%p base=%p rva=%I64x\n",e->ExceptionRecord->ExceptionCode,e->ExceptionRecord->ExceptionAddress,info.AllocationBase,static_cast<unsigned __int64>(reinterpret_cast<uintptr_t>(e->ExceptionRecord->ExceptionAddress)-reinterpret_cast<uintptr_t>(info.AllocationBase))); fflush(stdout);
    return EXCEPTION_EXECUTE_HANDLER;
}
int main(int argc, char **argv)
{
    SetUnhandledExceptionFilter(crashRecord);
    puts("STAGE main"); fflush(stdout);
    // Actual linked OsNewDel.cpp owns the sole static MemoryManager lifetime.
    puts("STAGE manager"); fflush(stdout);
    MemoryManager::setReportAllocations(false);
    MemoryManager::setLimit(32,true,false);
    // Isolated known-existing tracked-path negative, never counted as a passing check.
    if(argc==2 && strcmp(argv[1],"null-reallocate")==0) {
        void *p=MemoryManager::reallocate(0,16);
        if(p) MemoryManager::free(p,false);
        puts("NULL_REALLOC_RETURNED"); return 0;
    }
    int const initial=MemoryManager::getCurrentNumberOfAllocations();
    unsigned long const bytes=MemoryManager::getCurrentNumberOfBytesAllocated();
    void *slots[64]; size_t sizes[64];
    MemoryManager::OwnerAddress owners[64];
    puts("STAGE ready"); fflush(stdout);
    for(unsigned round=0;round<4;++round) {
        for(unsigned i=0;i<64;++i) {
            sizes[i]=1+i*37+round;
            owners[i]=static_cast<MemoryManager::OwnerAddress>(UINT64_C(0x1234567800000000)+0x1000+i*16);
            printf("STAGE allocate %u %u\n",round,i); fflush(stdout);
            slots[i]=MemoryManager::allocate(sizes[i],owners[i],(i&1)!=0,(i&2)!=0);
            CHECK(slots[i]!=0);
            if(!slots[i]) return 2;
            CHECK((reinterpret_cast<uintptr_t>(slots[i])&15)==0);
            CHECK(block(slots[i])->getOwner(0)==owners[i]);
            CHECK(block(slots[i])->isAllocatedAsArray()==((i&1)!=0));
            CHECK(block(slots[i])->checkForLeaks()==((i&2)!=0));
            memset(slots[i],static_cast<unsigned char>(i+round),sizes[i]);
        }
        MemoryManager::verify(true,true);
        for(unsigned i=0;i<64;++i) {
            void *p=MemoryManager::reallocate(slots[i],sizes[i]+257);
            CHECK(p!=0); if(!p) return 2;
            CHECK(contents(p,sizes[i],static_cast<unsigned char>(i+round)));
            CHECK(block(p)->getOwner(0)==owners[i]);
            CHECK(block(p)->isAllocatedAsArray()==((i&1)!=0));
            CHECK(block(p)->checkForLeaks()==((i&2)!=0));
            slots[i]=p;
        }
        // Odd/even release order exercises both coalescing directions.
        for(unsigned parity=0;parity<2;++parity)
            for(unsigned i=parity;i<64;i+=2) MemoryManager::free(slots[i],(i&1)!=0);
        MemoryManager::verify(true,true);
        CHECK(MemoryManager::getCurrentNumberOfAllocations()==initial);
        CHECK(MemoryManager::getCurrentNumberOfBytesAllocated()==bytes);
    }
    printf("checks=%u failures=%u expected=2568\n",checks,failures);
    fflush(stdout);
    return failures || checks!=2568;
}
