#include "MemoryManager-diagnostic.cpp"
#include <stdio.h>
#include <string.h>
static unsigned checks,failures;
#define CHECK(x) do { ++checks; if(!(x)) { ++failures; printf("FAIL line=%d\n",__LINE__); } } while(0)
int main()
{
    MemoryManager::setReportAllocations(false);
    using namespace MemoryManagerNamespace;
    FatalSetThrowExceptions(true);
    bool caught=false;
    try { MemoryManager::setLimit(-1,true,true); }
    catch(FatalException const &e) { caught=strstr(e.getMessage(),"negative memory limit")!=0; }
    CHECK(caught);
    CHECK(!ms_limitSet);
    int const regions=ms_numberOfSystemAllocations;
    int const initialMiB=ms_systemMemoryAllocatedMegabytes;
    allocateSystemMemory(0);
    CHECK(ms_numberOfSystemAllocations==regions);
    MemoryManager::setLimit(initialMiB+3,true,true);
    CHECK(ms_numberOfSystemAllocations==regions+3);
    CHECK(ms_systemMemoryAllocatedMegabytes==initialMiB+3);
    CHECK(MemoryManager::getLimit()==initialMiB+3);
    CHECK(MemoryManager::isHardLimit());
    allocateSystemMemory(INT_MAX);
    CHECK(ms_numberOfSystemAllocations==regions+3);
    caught=false;
    try { allocateSystemMemory(-1); }
    catch(FatalException const &e) { caught=strstr(e.getMessage(),"negative system allocation")!=0; }
    CHECK(caught);
    void *p=MemoryManager::allocate(256,123,false,true);
    CHECK(p!=0);
    memset(p,0x6c,256);
    CHECK(static_cast<byte *>(p)[255]==0x6c);
    MemoryManager::free(p,false);
    CHECK(ms_systemMemoryAllocatedMegabytes==initialMiB+3);
    FatalSetThrowExceptions(false);
    printf("checks=%u failures=%u expected=12\n",checks,failures);fflush(stdout);
    return failures || checks!=12;
}
