import json,struct,sys
from pathlib import Path
def read(p):
 raw=Path(p).read_bytes();assert len(raw)==16+2688*1104*4 and struct.unpack_from('<4I',raw)==(0x534b4831,1,2688,1104)
 return list(struct.iter_unpack('<1104I',raw[16:]))
a,b=map(read,sys.argv[1:]);diffs=[];finite=0
for i,(x,y) in enumerate(zip(a,b)):
 assert x[0]==y[0]==i and x[:10]==y[:10] and x[11:14]==y[11:14],('input mismatch',i)
 assert x[14]==y[14]==0,('contract failure',i)
 changed=[{'word':j,'stock':hex(x[j]),'candidate':hex(y[j])} for j in range(10,1104) if x[j]!=y[j]]
 if changed:
  diffs.append(dict(record=i,category=x[2],words=changed));finite+=x[2]<2
print(json.dumps(dict(records=2688,different_records=len(diffs),finite_differences=finite,differences=diffs),indent=2));sys.exit(bool(finite))
