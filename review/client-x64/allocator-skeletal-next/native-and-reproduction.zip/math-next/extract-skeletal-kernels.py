"""Exact source slices. This lowers runtime coverage to kernels, not the renderer TU."""
import hashlib,json
from pathlib import Path
root=Path(__file__).parent
manifest=[]
for mode in ['stock','candidate']:
 p=root/(mode+'-SoftwareBlendSkeletalShaderPrimitive.cpp');raw=p.read_bytes();s=raw.decode();parts=[];ranges=[]
 def add(start,end):
  i=s.index(start);j=s.index(end,i);t=s[i:j];parts.append(t);ranges.append(dict(first_line=s.count('\n',0,i)+1,last_line=s.count('\n',0,j)+1,sha256=hashlib.sha256(t.encode()).hexdigest()))
 add('// ======================================================================','// ==============================================================================\n// SofwareBlendSkeletalShaderPrimitive Namespace')
 add('namespace SofwareBlendSkeletalShaderPrimitiveNamespace','\ttypedef stdvector<PackedArgb>')
 parts.append('}\nusing namespace SofwareBlendSkeletalShaderPrimitiveNamespace;\n')
 add('struct SoftwareBlendSkeletalShaderPrimitive::TransformData','class SoftwareBlendSkeletalShaderPrimitive::RenderCommand')
 add('struct fill_vb_work;','// class SoftwareBlendSkeletalShaderPrimitive::RenderCommand')
 add('#if TRY_FOR_SSE\n// ============================================================================','void fill_vb_work::fillDot3VertexBufferHard() const')
 result='\n'.join(parts);out=root/(mode+'-skeletal-kernels.cpp');out.write_text(result)
 manifest.append(dict(mode=mode,source=str(p.name),source_sha256=hashlib.sha256(raw).hexdigest(),slice_file=out.name,slice_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),ranges=ranges,synthetic_lines=['namespace closure and using directive only'],scope='Exact kernel/data-definition slices and real headers; renderer and globals excluded; no replacement definitions'))
(root/'skeletal-slices-manifest.json').write_text(json.dumps(manifest,indent=2))
