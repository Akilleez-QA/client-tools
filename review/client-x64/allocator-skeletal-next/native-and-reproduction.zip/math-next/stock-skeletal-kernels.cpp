// ======================================================================
//
// SoftwareBlendSkeletalShaderPrimitive.cpp
// Copyright 2001 Sony Online Entertainment Inc.
// All Rights Reserved.
// 
// ======================================================================

#include "clientSkeletalAnimation/FirstClientSkeletalAnimation.h"
#include "clientSkeletalAnimation/SoftwareBlendSkeletalShaderPrimitive.h"

#include "clientGraphics/Camera.h"
#include "clientGraphics/ConfigClientGraphics.h"
#include "clientGraphics/CustomizableShader.h"
#include "clientGraphics/DebugPrimitive.h"
#include "clientGraphics/DynamicVertexBuffer.h"
#include "clientGraphics/Graphics.h"
#include "clientGraphics/GraphicsDebugFlags.h"
#include "clientGraphics/Shader.h"
#include "clientGraphics/ShaderPrimitiveSorter.h"
#include "clientGraphics/ShaderTemplate.h"
#include "clientGraphics/ShaderTemplateList.h"
#include "clientGraphics/StaticShader.h"
#include "clientGraphics/SystemVertexBuffer.h"
#include "clientGraphics/Texture.h"
#include "clientGraphics/VertexBuffer.h"
#include "clientGraphics/VertexBufferVector.h"
#include "clientGraphics/VertexBufferIterator.h"
#include "clientObject/ShadowManager.h"
#include "clientObject/ShadowVolume.h"
#include "clientSkeletalAnimation/ConfigClientSkeletalAnimation.h"
#include "clientSkeletalAnimation/MeshConstructionHelper.h"
#include "clientSkeletalAnimation/OwnerProxyShader.h"
#include "clientSkeletalAnimation/SkeletalAppearance2.h"
#include "clientSkeletalAnimation/Skeleton.h"
#include "clientSkeletalAnimation/PoseModelTransform.h"
#include "sharedCollision/CollisionInfo.h"
#include "sharedDebug/Profiler.h"
#include "sharedFoundation/ExitChain.h"
#include "sharedFoundation/MemoryBlockManager.h"
#include "sharedFoundation/Os.h"
#include "sharedFoundation/PointerDeleter.h"
#include "sharedFoundation/VoidMemberFunction.h"
#include "sharedMath/PaletteArgb.h"
#include "sharedMath/Plane.h"
#include "sharedMath/SSeMath.h"
#include "sharedMath/VectorArgb.h"
#include "sharedObject/AppearanceTemplate.h"
#include "sharedObject/ConfigSharedObject.h"
#include "sharedObject/CustomizationData.h"
#include "sharedObject/Object.h"
#include "sharedObject/PaletteColorCustomizationVariable.h"

#include <algorithm>
#include <limits>
#include <string>
#include <vector>
#include <malloc.h>

//-----------------------------------
#undef TRY_FOR_SSE
#define TRY_FOR_SSE WIN32

#if TRY_FOR_SSE
#include "sharedMath/SseMath.h"
#endif


namespace SofwareBlendSkeletalShaderPrimitiveNamespace
{
	typedef SoftwareBlendSkeletalShaderPrimitive::Dot3Vector Dot3Vector;
	typedef SoftwareBlendSkeletalShaderPrimitive::SourceVertex SourceVertex;
	typedef SoftwareBlendSkeletalShaderPrimitive::TransformData TransformData;

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

	struct __declspec(align(16)) PaddedVector : public Vector
	{
		PaddedVector &operator=(const PaddedVector &o) { x=o.x; y=o.y; z=o.z; return *this; }
		PaddedVector &operator=(const Vector &o) { x=o.x; y=o.y; z=o.z; return *this; }

		float pad;
	};

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


}
using namespace SofwareBlendSkeletalShaderPrimitiveNamespace;

struct SoftwareBlendSkeletalShaderPrimitive::TransformData
{
	int  m_transformIndex;
	real m_transformWeight;
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

struct SoftwareBlendSkeletalShaderPrimitive::Dot3Vector
{
	Dot3Vector() {}
	Dot3Vector(const Vector &v, float f) : m_dot3Vector(v), m_flipState(f) {}

	Vector  m_dot3Vector;
	float   m_flipState;
};
#define SOURCE_DOT3_SIZE 16
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
struct SoftwareBlendSkeletalShaderPrimitive::SourceVertex
{
	TransformData m_firstTransformData;
	int           m_extraTransformDataCount;
	Vector        m_position;
	Vector        m_normal;
};
#define SOURCE_VERTEX_SIZE 36 // TODO: this is lame.  Need to figure out how to get the inline assembler to do this
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


struct fill_vb_work;

void _fillDot3VertexBufferHard_sse(const fill_vb_work *w);
void _fillVertexBufferHard_sse(const fill_vb_work *w);

struct fill_vb_work
{
	void construct(
		int                       i_vertexCount, 
		const SourceVertex       *i_sourceVectors, 
		const Dot3Vector         *i_sourceDot3Vectors, 
		const PoseModelTransform *i_transformArray,
		int                       i_vertexSize,
		byte                     *i_viter,
		byte                     *i_dot3viter
		)
	{
		vertexCount          = i_vertexCount;
		m_sourceVectors      = i_sourceVectors;
		m_sourceDot3Vectors  = i_sourceDot3Vectors;
		transformArray       = i_transformArray;
		vertexSize           = i_vertexSize;
		viter                = i_viter;
		dot3viter            = i_dot3viter;
		//------------------------------------------
		m_sourceVectorsEnd     = m_sourceVectors + vertexCount;
		m_sourceVectorPrefetch = ((uint8 *)m_sourceVectors) + 256;
		if (m_sourceDot3Vectors)
		{
			m_sourceDot3VectorsEnd = m_sourceDot3Vectors + vertexCount;
			m_sourceVectorDot3Prefetch = ((uint8 *)m_sourceDot3Vectors) + 256;
		}
		xf=0;
		identity.makeIdentity();
		//------------------------------------------
		minVector.set( std::numeric_limits<float>::max(),  std::numeric_limits<float>::max(),  std::numeric_limits<float>::max());
		maxVector.set(-std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(), -std::numeric_limits<float>::max());
		//------------------------------------------
	}

	void fillDot3VertexBufferHard() const;
	void fillVertexBufferHard() const;

#if TRY_FOR_SSE
	void fillDot3VertexBufferHard_sse() const { _fillDot3VertexBufferHard_sse(this); }
	void fillVertexBufferHard_sse() const { _fillVertexBufferHard_sse(this); }
#endif

	PoseModelTransform identity;

	mutable PaddedVector        position;
	mutable PaddedVector        normal;
	mutable PaddedVector        dot3;
	mutable PaddedVector        minVector;
	mutable PaddedVector        maxVector;
	mutable const PoseModelTransform *xf;
	mutable byte               *viter;
	mutable byte               *dot3viter;
	mutable const SourceVertex *m_sourceVectors;
	mutable const uint8        *m_sourceVectorPrefetch;
	mutable const Dot3Vector   *m_sourceDot3Vectors;
	mutable const uint8        *m_sourceVectorDot3Prefetch;

	const PoseModelTransform *transformArray;
	int                 vertexCount;
	const SourceVertex *m_sourceVectorsEnd;
	const Dot3Vector   *m_sourceDot3VectorsEnd;
	int                 vertexSize;
};

// ======================================================================

// ======================================================================

#if TRY_FOR_SSE
// ============================================================================
void _fillDot3VertexBufferHard_sse(const fill_vb_work *const w)
{
	uint32 mxcsrSave, mxcsrTemp;

	_asm {
		mov	esi, w // "this" pointer

		mov	eax, [esi]fill_vb_work.m_sourceVectors
		mov	ebx, [esi]fill_vb_work.m_sourceVectorsEnd
		mov	ecx, [esi]fill_vb_work.m_sourceDot3Vectors
		mov	edx, [esi]fill_vb_work.m_sourceDot3VectorsEnd

		sub	ebx, eax // length of sourceVectors array
		sub	edx, ecx // length of sourceDot3Vectors array

		// ----------------------------------------------------
		// check the length of sourceVectors array.  If it is
		// greater than 256, pre-fetch all the cache lines
		// for the first 256 bytes.
		cmp	      ebx, 256
		jl		      skip_vec_prefetch
		prefetchnta [eax+  0]
		prefetchnta [eax+ 32]
		prefetchnta [eax+ 64]
		prefetchnta [eax+ 96]
		prefetchnta [eax+128]
		prefetchnta [eax+160]
		prefetchnta [eax+192]
		prefetchnta [eax+224]
	skip_vec_prefetch:		
		// ----------------------------------------------------

		// ----------------------------------------------------
		// check the length of sourceDot3Vectors data array.  If it is
		// greater than 256, pre-fetch all the cache lines
		// for the first 256 bytes.
		cmp	      edx, 256
		jl		      skip_dot3_prefetch
		prefetchnta [ecx+  0]
		prefetchnta [ecx+ 32]
		prefetchnta [ecx+ 64]
		prefetchnta [ecx+ 96]
		prefetchnta [ecx+128]
		prefetchnta [ecx+160]
		prefetchnta [ecx+192]
		prefetchnta [ecx+224]
	skip_dot3_prefetch:
		// ----------------------------------------------------

		// ----------------------------------------------------
		// save the mxcsr register then mask exceptions and enable 
		// "flush-to_zero" mode.
		stmxcsr     mxcsrSave
		mov         eax, mxcsrSave
		or          eax, (MXCSR_FLUSH_TO_ZERO|MXCSR_PRECISION_MASK|MXCSR_UNDERFLOW_MASK|MXCSR_OVERFLOW_MASK|MXCSR_DENORMAL_MASK)
		mov         mxcsrTemp, eax
		ldmxcsr     mxcsrTemp
		// ----------------------------------------------------

		// ----------------------------------------------------
		//-- Skin position, normal and dot3.
		mov         ebx, [esi]fill_vb_work.m_sourceVectors      // current vertex pointer
		jmp	main_loop_test
	main_loop_top:
			// ----------------------------------------------------
			// pre-fectch sourceVector data

			// check to make sure the pre-fetcher is at least 32 bytes 
			// from the end of the array.
			mov	eax, [esi]fill_vb_work.m_sourceVectorPrefetch
			mov	ebx, [esi]fill_vb_work.m_sourceVectorsEnd
			sub	ebx, eax
			cmp	ebx, 32
			jl		skip_vec_prefetch2
				// ----------------------------------------------
				// while the pre-fetcher is less than 256 bytes away
				// from the current source location, pre-fetch in
				// 32 byte (cache line) increments
				//
				// eax contains m_sourceVectorPrefetch from above
				mov	      ebx, [esi]fill_vb_work.m_sourceVectors
				lea	      ebx, [ebx + 256]	// pointer 256 bytes ahead of current source
				jmp	      vec_prefetch_loop
			vec_prefetch2:
				prefetchnta [eax]                 // pre-fetch
				lea			eax, [eax + 32]       // advance pre-fetcher by cache line
			vec_prefetch_loop:
				cmp         eax, ebx              // compare pre-fetch to source+256
				jl          vec_prefetch2         // if less, pre-fetch
				mov         [esi]fill_vb_work.m_sourceVectorPrefetch, eax // update pre-fetcher var
				// ----------------------------------------------
		skip_vec_prefetch2:
			// ----------------------------------------------------

			// ----------------------------------------------------
			// pre-fectch m_sourceVectorDot3 data

			// check to make sure the pre-fetcher is at least 32 bytes 
			// from the end of the array.
			mov	eax, [esi]fill_vb_work.m_sourceVectorDot3Prefetch
			mov	ebx, [esi]fill_vb_work.m_sourceDot3VectorsEnd
			sub	ebx, eax
			cmp	ebx, 32
			jl		skip_dot3_prefetch2

				// ----------------------------------------------
				// while the dot3 pre-fetcher is less than 256 bytes away
				// from the current source location, pre-fetch in
				// 32 byte (cache line) increments
				//
				// eax contains m_sourceVectorDot3Prefetch from above
				mov	      ebx, [esi]fill_vb_work.m_sourceDot3Vectors
				lea	      ebx, [ebx + 256]   	// pointer 256 bytes ahead of current source
				jmp	      dot3_prefetch_loop
			dot3_prefetch2:
				prefetchnta [eax]                 // pre-fetch
				lea			eax, [eax + 32]       // advance pre-fetcher by cache line
			dot3_prefetch_loop:
				cmp         eax, ebx              // compare pre-fetch to source+256
				jl          dot3_prefetch2         // if less, pre-fetch
				mov         [esi]fill_vb_work.m_sourceVectorDot3Prefetch, eax // update dot3 pre-fetcher var
				// ----------------------------------------------
		skip_dot3_prefetch2:
			// ----------------------------------------------------

			mov         ebx, [esi]fill_vb_work.m_sourceVectors      // current vertex pointer

			// ----------------------------------------------------
			// Initialize first position and normal.
			mov         edi, [ebx]TransformData.m_transformIndex    // current vertex transform index
			shl         edi, 6                                      // current vertex transform offset
			mov         edx, [esi]fill_vb_work.transformArray       // transfrom array
			lea         eax, [edx + edi]
			// ----------------------------------------------------

			///////////////////////////////////////////////////////////////
			// rotateTranslate the source position
			//----------------------------------------------------------
			// rotateTranslate_l2p
			// eax -> 4x4 column-major float transform (16 byte aligned).
			// ebx -> source vertex
			movaps xmm0, [eax +  0]                          // column 0 (Cx_)
			movss  xmm4, [ebx +  0]SourceVertex.m_position   // source vector x
			movaps xmm1, [eax + 16]                          // column 1 (Cy_)
			movss  xmm5, [ebx +  4]SourceVertex.m_position   // source vector y
			movaps xmm2, [eax + 32]                          // column 2 (Cz_)
			movss  xmm6, [ebx +  8]SourceVertex.m_position   // source vector z
			movaps xmm3, [eax + 48]                          // column 3 (O_)

			shufps xmm4, xmm4, 0      // x -> x.x.x.x
			shufps xmm5, xmm5, 0      // y -> y.y.y.y
			shufps xmm6, xmm6, 0      // z -> z.z.z.z

			mulps  xmm0, xmm4         // col0 * x.x.x.x
			mulps  xmm1, xmm5         // col1 * y.y.y.y
			mulps  xmm2, xmm6         // col2 * z.z.z.z

			addps  xmm0, xmm1         // col0*x + col1*y
			addps  xmm2, xmm3         // col2*z + col3
			addps  xmm0, xmm2         // col0*x + col1*y + col2*z + col3

			movaps [esi]fill_vb_work.position, xmm0           // save result out
			///////////////////////////////////////////////////////////////

			///////////////////////////////////////////////////////////////
			// update the bounding box with the position currently in xmm0
			movaps	xmm1, xmm0      // save off a copy of the position for the "min" test
			maxps		xmm0, [esi]fill_vb_work.maxVector
			minps		xmm1, [esi]fill_vb_work.minVector
			movaps	[esi]fill_vb_work.maxVector, xmm0
			movaps	[esi]fill_vb_work.minVector, xmm1
			///////////////////////////////////////////////////////////////

			///////////////////////////////////////////
			// rotate the source normal
			//----------------------------------------------------------
			// rotate_l2p
			// eax -> 4x4 column-major float transform (16 byte aligned).
			// ebx -> source vertex
			movaps xmm0, [eax +  0]                        // column 0 (Cx_)
			movss  xmm4, [ebx +  0]SourceVertex.m_normal   // source vector x
			movaps xmm1, [eax + 16]                        // column 1 (Cy_)
			movss  xmm5, [ebx +  4]SourceVertex.m_normal   // source vector y
			movaps xmm2, [eax + 32]                        // column 2 (Cz_)
			movss  xmm6, [ebx +  8]SourceVertex.m_normal   // source vector z

			shufps xmm4, xmm4, 0      // x -> x.x.x.x
			shufps xmm5, xmm5, 0      // y -> y.y.y.y
			shufps xmm6, xmm6, 0      // z -> z.z.z.z

			mulps  xmm0, xmm4         // col0 * x.x.x.x
			mulps  xmm1, xmm5         // col1 * y.y.y.y
			mulps  xmm2, xmm6         // col2 * z.z.z.z

			addps  xmm0, xmm1         // col0*x + col1*y
			addps  xmm0, xmm2         // col0*x + col1*y + col2*z

			movaps [esi]fill_vb_work.normal, xmm0           // save result out
			///////////////////////////////////////////////////////////////

			///////////////////////////////////////////////////////////////
			// rotate the source dot3 vector
			mov	ebx, [esi]fill_vb_work.m_sourceDot3Vectors
			//----------------------------------------------------------
			// rotate_l2p
			// eax -> 4x4 column-major float transform (16 byte aligned).
			// ebx -> 3 float source vector
			movaps xmm0, [eax +  0]                          // column 0 (Cx_)
			movss  xmm4, [ebx +  0]Dot3Vector.m_dot3Vector   // source vector x
			movaps xmm1, [eax + 16]                          // column 1 (Cy_)
			movss  xmm5, [ebx +  4]Dot3Vector.m_dot3Vector   // source vector y
			movaps xmm2, [eax + 32]                          // column 2 (Cz_)
			movss  xmm6, [ebx +  8]Dot3Vector.m_dot3Vector   // source vector z

			shufps xmm4, xmm4, 0      // x -> x.x.x.x
			shufps xmm5, xmm5, 0      // y -> y.y.y.y
			shufps xmm6, xmm6, 0      // z -> z.z.z.z

			mulps  xmm0, xmm4         // col0 * x.x.x.x
			mulps  xmm1, xmm5         // col1 * y.y.y.y
			mulps  xmm2, xmm6         // col2 * z.z.z.z

			addps  xmm0, xmm1         // col0*x + col1*y
			addps  xmm0, xmm2         // col0*x + col1*y + col2*z

			movaps [esi]fill_vb_work.dot3, xmm0           // save result out
			///////////////////////////////////////////////////////////////

			///////////////////////////////////////////////////////////////
			//-- Write out render geometry.
			//*(Vector *)(w->viter +  0) = w->position;
			//*(Vector *)(w->viter + 12) = w->normal;
			//*(float *)(w->dot3viter + 0) = w->dot3.x;
			//*(float *)(w->dot3viter + 4) = w->dot3.y;
			//*(float *)(w->dot3viter + 8) = w->dot3.z;
			//*(float *)(w->dot3viter +12) = w->m_sourceDot3Vectors->m_flipState;
			//
			// ebx contains m_sourceDot3Vectors from above

			mov         eax, [esi]fill_vb_work.dot3viter    // destination dot3 pointer
			mov         edi, [esi]fill_vb_work.viter        // destination pointer

			// position and normal
			mov         ecx, [esi + 0]fill_vb_work.position // xf'ed position.x
			mov         edx, [esi + 4]fill_vb_work.position // xf'ed position.y
			mov         [edi + 0], ecx
			mov         [edi + 4], edx
			mov         ecx, [esi + 8]fill_vb_work.position // xf'ed position.z
			mov         edx, [esi + 0]fill_vb_work.normal   // xf'ed normal.x
			mov         [edi + 8], ecx
			mov         [edi +12], edx
			mov         ecx, [esi + 4]fill_vb_work.normal   // xf'ed normal.y
			mov         edx, [esi + 8]fill_vb_work.normal   // xf'ed normal.z
			mov         [edi +16], ecx
			mov         [edi +20], edx

			// dot-3
			mov         ecx, [esi + 0]fill_vb_work.dot3     // xf'ed dot3.x
			mov         edx, [esi + 4]fill_vb_work.dot3     // xf'ed dot3.y
			mov         [eax + 0], ecx
			mov         [eax + 4], edx
			mov         ecx, [esi + 8]fill_vb_work.dot3     // xf'ed dot3.z
			mov         edx, [ebx]Dot3Vector.m_flipState    // source Dot3Vector flip-state
			mov         [eax + 8], ecx
			mov         [eax +12], edx
			///////////////////////////////////////////////////////////////

			// ------------------------------
			//w->m_sourceVectors++;
			//w->m_sourceDot3Vectors++;
			//w->viter+=w->vertexSize;
			//w->dot3viter+=w->vertexSize;
			//
			// eax contains dot3viter from above
			// edi contains viter from above
			add         eax, [esi]fill_vb_work.vertexSize
			add         edi, [esi]fill_vb_work.vertexSize
			mov         [esi]fill_vb_work.dot3viter, eax
			mov         [esi]fill_vb_work.viter, edi

			mov         ebx, [esi]fill_vb_work.m_sourceVectors      // current vertex pointer
			mov         ecx, [esi]fill_vb_work.m_sourceDot3Vectors  // current dot3 pointer

			lea         ebx, BYTE PTR [ebx + SOURCE_VERTEX_SIZE]
			add         ecx, SOURCE_DOT3_SIZE

			mov         [esi]fill_vb_work.m_sourceVectors, ebx
			mov         [esi]fill_vb_work.m_sourceDot3Vectors, ecx
			// ------------------------------

		// end of main loop body
		// ------------------------------
	main_loop_test:
		//while (w->m_sourceVectors!=w->m_sourceVectorsEnd)
		cmp            ebx, [esi]fill_vb_work.m_sourceVectorsEnd
		jnz            main_loop_top

		// -----------------------------------
		// restore mxcsr
		ldmxcsr mxcsrSave
		// -----------------------------------
	}
	//--------------------------------------------------------------------------------------------
}
// ============================================================================
void _fillVertexBufferHard_sse(const fill_vb_work *const w)
{
	uint32 mxcsrSave, mxcsrTemp;

	_asm {
		mov	esi, w // "this" pointer

		mov	eax, [esi]fill_vb_work.m_sourceVectors
		mov	ebx, [esi]fill_vb_work.m_sourceVectorsEnd

		sub	ebx, eax // length of sourceVectors array

		// ----------------------------------------------------
		// check the length of sourceVectors array.  If it is
		// greater than 256, pre-fetch all the cache lines
		// for the first 256 bytes.
		cmp	      ebx, 256
		jl		      skip_vec_prefetch
		prefetchnta [eax+  0]
		prefetchnta [eax+ 32]
		prefetchnta [eax+ 64]
		prefetchnta [eax+ 96]
		prefetchnta [eax+128]
		prefetchnta [eax+160]
		prefetchnta [eax+192]
		prefetchnta [eax+224]
	skip_vec_prefetch:		
		// ----------------------------------------------------

		// ----------------------------------------------------
		// save the mxcsr register then mask exceptions and enable 
		// "flush-to_zero" mode.
		stmxcsr     mxcsrSave
		mov         eax, mxcsrSave
		or          eax, (MXCSR_FLUSH_TO_ZERO|MXCSR_PRECISION_MASK|MXCSR_UNDERFLOW_MASK|MXCSR_OVERFLOW_MASK|MXCSR_DENORMAL_MASK)
		mov         mxcsrTemp, eax
		ldmxcsr     mxcsrTemp
		// ----------------------------------------------------

		// ----------------------------------------------------
		//-- Skin position, normal and dot3.
		mov         ebx, [esi]fill_vb_work.m_sourceVectors      // current vertex pointer
		jmp	      main_loop_test
	main_loop_top:
			// ----------------------------------------------------
			// pre-fectch sourceVector data

			// check to make sure the pre-fetcher is at least 32 bytes 
			// from the end of the array.
			mov	eax, [esi]fill_vb_work.m_sourceVectorPrefetch
			mov	ebx, [esi]fill_vb_work.m_sourceVectorsEnd
			sub	ebx, eax
			cmp	ebx, 32
			jl		skip_vec_prefetch2
				// ----------------------------------------------
				// while the pre-fetcher is less than 256 bytes away
				// from the current source location, pre-fetch in
				// 32 byte (cache line) increments
				//
				// eax contains m_sourceVectorPrefetch from above
				mov	      ebx, [esi]fill_vb_work.m_sourceVectors
				lea	      ebx, [ebx + 256]	// pointer 256 bytes ahead of current source
				jmp	      vec_prefetch_loop
			vec_prefetch2:
				prefetchnta [eax]                 // pre-fetch
				lea			eax, [eax + 32]       // advance pre-fetcher by cache line
			vec_prefetch_loop:
				cmp         eax, ebx              // compare pre-fetch to source+256
				jl          vec_prefetch2         // if less, pre-fetch
				mov         [esi]fill_vb_work.m_sourceVectorPrefetch, eax // update pre-fetcher var
				// ----------------------------------------------
		skip_vec_prefetch2:
			// ----------------------------------------------------

			mov         ebx, [esi]fill_vb_work.m_sourceVectors      // current vertex pointer

			// ----------------------------------------------------
			// Initialize first position and normal.
			mov         edi, [ebx]TransformData.m_transformIndex    // current vertex transform index
			shl         edi, 6                                      // current vertex transform offset
			mov         edx, [esi]fill_vb_work.transformArray       // transfrom array
			lea         eax, [edx + edi]
			// ----------------------------------------------------

			///////////////////////////////////////////////////////////////
			// rotateTranslate the source position
			//----------------------------------------------------------
			// rotateTranslate_l2p
			// eax -> 4x4 column-major float transform (16 byte aligned).
			// ebx -> source vertex
			movaps xmm0, [eax +  0]                          // column 0 (Cx_)
			movss  xmm4, [ebx +  0]SourceVertex.m_position   // source vector x
			movaps xmm1, [eax + 16]                          // column 1 (Cy_)
			movss  xmm5, [ebx +  4]SourceVertex.m_position   // source vector y
			movaps xmm2, [eax + 32]                          // column 2 (Cz_)
			movss  xmm6, [ebx +  8]SourceVertex.m_position   // source vector z
			movaps xmm3, [eax + 48]                          // column 3 (O_)

			shufps xmm4, xmm4, 0      // x -> x.x.x.x
			shufps xmm5, xmm5, 0      // y -> y.y.y.y
			shufps xmm6, xmm6, 0      // z -> z.z.z.z

			mulps  xmm0, xmm4         // col0 * x.x.x.x
			mulps  xmm1, xmm5         // col1 * y.y.y.y
			mulps  xmm2, xmm6         // col2 * z.z.z.z

			addps  xmm0, xmm1         // col0*x + col1*y
			addps  xmm2, xmm3         // col2*z + col3
			addps  xmm0, xmm2         // col0*x + col1*y + col2*z + col3

			movaps [esi]fill_vb_work.position, xmm0           // save result out
			///////////////////////////////////////////////////////////////

			///////////////////////////////////////////////////////////////
			// update the bounding box with the position currently in xmm0
			movaps	xmm1, xmm0      // save off a copy of the position for the "min" test
			maxps		xmm0, [esi]fill_vb_work.maxVector
			minps		xmm1, [esi]fill_vb_work.minVector
			movaps	[esi]fill_vb_work.maxVector, xmm0
			movaps	[esi]fill_vb_work.minVector, xmm1
			///////////////////////////////////////////////////////////////

			///////////////////////////////////////////
			// rotate the source normal
			//----------------------------------------------------------
			// rotate_l2p
			// eax -> 4x4 column-major float transform (16 byte aligned).
			// ebx -> source vertex
			movaps xmm0, [eax +  0]                        // column 0 (Cx_)
			movss  xmm4, [ebx +  0]SourceVertex.m_normal   // source vector x
			movaps xmm1, [eax + 16]                        // column 1 (Cy_)
			movss  xmm5, [ebx +  4]SourceVertex.m_normal   // source vector y
			movaps xmm2, [eax + 32]                        // column 2 (Cz_)
			movss  xmm6, [ebx +  8]SourceVertex.m_normal   // source vector z

			shufps xmm4, xmm4, 0      // x -> x.x.x.x
			shufps xmm5, xmm5, 0      // y -> y.y.y.y
			shufps xmm6, xmm6, 0      // z -> z.z.z.z

			mulps  xmm0, xmm4         // col0 * x.x.x.x
			mulps  xmm1, xmm5         // col1 * y.y.y.y
			mulps  xmm2, xmm6         // col2 * z.z.z.z

			addps  xmm0, xmm1         // col0*x + col1*y
			addps  xmm0, xmm2         // col0*x + col1*y + col2*z

			movaps [esi]fill_vb_work.normal, xmm0           // save result out
			///////////////////////////////////////////////////////////////

			///////////////////////////////////////////////////////////////
			//-- Write out render geometry.
			//*(Vector *)(w->viter +  0) = w->position;
			//*(Vector *)(w->viter + 12) = w->normal;
			mov         edi, [esi]fill_vb_work.viter        // destination pointer

			// position and normal
			mov         ecx, [esi + 0]fill_vb_work.position // xf'ed position.x
			mov         edx, [esi + 4]fill_vb_work.position // xf'ed position.y
			mov         [edi + 0], ecx
			mov         [edi + 4], edx
			mov         ecx, [esi + 8]fill_vb_work.position // xf'ed position.z
			mov         edx, [esi + 0]fill_vb_work.normal   // xf'ed normal.x
			mov         [edi + 8], ecx
			mov         [edi +12], edx
			mov         ecx, [esi + 4]fill_vb_work.normal   // xf'ed normal.y
			mov         edx, [esi + 8]fill_vb_work.normal   // xf'ed normal.z
			mov         [edi +16], ecx
			mov         [edi +20], edx
			///////////////////////////////////////////////////////////////

			// ------------------------------
			//w->m_sourceVectors++;
			//w->viter+=w->vertexSize;
			//
			// edi contains viter from above
			add         edi, [esi]fill_vb_work.vertexSize
			mov         [esi]fill_vb_work.viter, edi

			mov         ebx, [esi]fill_vb_work.m_sourceVectors      // current vertex pointer
			lea         ebx, BYTE PTR [ebx + SOURCE_VERTEX_SIZE]
			mov         [esi]fill_vb_work.m_sourceVectors, ebx
			// ------------------------------

		// end of main loop body
		// ------------------------------
	main_loop_test:
		//while (w->m_sourceVectors!=w->m_sourceVectorsEnd)
		cmp            ebx, [esi]fill_vb_work.m_sourceVectorsEnd
		jnz            main_loop_top

		// -----------------------------------
		// restore mxcsr
		ldmxcsr mxcsrSave
		// -----------------------------------
	}
	//--------------------------------------------------------------------------------------------
}
// ============================================================================
#endif

