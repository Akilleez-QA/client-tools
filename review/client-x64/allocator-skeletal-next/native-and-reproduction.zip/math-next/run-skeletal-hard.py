#!/usr/bin/env python3
"""Native v120 real-TU observations; linker failures stay failures, no symbol stand-ins."""
import argparse, hashlib, json, os, shutil, struct, subprocess, sys
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--checkout',type=Path,default=Path('C:/client-next-build'))
p.add_argument('--inputs',type=Path,default=Path('C:/math-next'))
p.add_argument('--output',type=Path,required=True)
p.add_argument('--audit',type=Path,default=Path('C:/client-next-results'))
p.add_argument('--probe',default='skeletal-hard-probe.cpp')
p.add_argument('--comparator',default='compare-skeletal-hard.py')
p.add_argument('--expected-records',type=int,default=2688)
p.add_argument('--record-words',type=int,default=1104)
p.add_argument('--record-version',type=int,default=1)
p.add_argument('--record-magic',type=lambda x:int(x,0),default=0x534b4831)
p.add_argument('--source',type=Path)
p.add_argument('--libraries-json',type=Path)
p.add_argument('--configuration',choices=['Debug','Release'],action='append')
p.add_argument('--fp',choices=['precise','strict','fast'],default='precise')
p.add_argument('--win32-library',action='append',default=[])
p.add_argument('--x64-library',action='append',default=[])
p.add_argument('--suppress-unused-stlport-autolink',action='store_true',help='Diagnostic only; no fallback symbols supplied. Used symbols must still resolve.')
a=p.parse_args();root=a.checkout.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
project=root/'src/engine/client/library/clientSkeletalAnimation/build/win32'
source=root/'src/engine/client/library/clientSkeletalAnimation/src/shared/appearance/SoftwareBlendSkeletalShaderPrimitive.cpp'
if a.source:source=a.source.resolve()
probe=a.inputs/a.probe;stock=a.inputs/'stock-SoftwareBlendSkeletalShaderPrimitive.cpp';comparator=a.inputs/a.comparator
vcvars=Path('C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat')
results=[];comparisons=[]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def execute(cmd,wd,env,log,timeout=180):
    try:
        r=subprocess.run(cmd,cwd=wd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
        log.write_bytes(r.stdout);return r.returncode,r.stdout
    except subprocess.TimeoutExpired as e:
        log.write_bytes((e.stdout or b'')+b'\nTIMEOUT\n');return -999,e.stdout or b''
for config in (a.configuration or ['Debug','Release']):
    for platform,arch,machine in [('Win32','x86',0x14c),('x64','amd64',0x8664)]:
        setup=out/(config+'-'+platform+'-environment.cmd')
        setup.write_text('@echo off\ncall "'+str(vcvars)+'" '+arch+' >nul\nif errorlevel 1 exit /b %errorlevel%\nset\n')
        # Environment may include credentials; never persist its output.
        setup_result=subprocess.run(['cmd','/d','/c',str(setup)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
        if setup_result.returncode:raise RuntimeError('vcvars failed')
        env={k.upper():v for k,v in os.environ.items()}
        for line in setup_result.stdout.decode(errors='replace').splitlines():
            if '=' in line and not line.startswith('='):
                k,v=line.split('=',1);env[k.upper()]=v
        cl=shutil.which('cl.exe',path=env['PATH']);link=shutil.which('link.exe',path=env['PATH'])
        if not cl or not link:raise RuntimeError('tool missing')
        audit=a.audit/('clientSkeletalAnimation-'+config+'-'+platform+'.audit.log')
        rows=[l.strip().split('|') for l in audit.read_text(encoding='utf-8-sig').splitlines() if l.strip().startswith('CL|')]
        row=next(r for r in rows if r[1].replace('\\','/').endswith('/SoftwareBlendSkeletalShaderPrimitive.cpp'))
        for mode,tu in [('candidate',source),('stock',stock)]:
            d=out/(config+'-'+platform+'-'+mode);d.mkdir()
            r=dict(name=d.name,config=config,platform=platform,mode=mode,source_sha256=digest(tu),probe_sha256=digest(probe),audit_sha256=digest(audit),fp=a.fp,status='failed',tool=cl)
            results.append(r)
            guard=d/'require-v120.h';guard.write_text('#if !defined(_MSC_VER) || _MSC_VER != 1800\n#error Native VS2013 v120 required\n#endif\n')
            flags=['/nologo','/EHsc','/Y-','/Zc:wchar_t-','/Gy','/fp:'+a.fp,'/MTd' if config=='Debug' else '/MT','/Od' if config=='Debug' else '/O2','/FI'+str(guard)]
            flags+=['/D'+v for v in row[6].split(';') if v]+['/I'+v for v in row[7].split(';') if v]
            # Include the exact source selected for this run. No production symbol stand-ins.
            driver=d/'driver.cpp'
            driver.write_text(probe.read_text().replace('#include "SoftwareBlendSkeletalShaderPrimitive.cpp"', '#include "'+tu.as_posix()+'"', 1))
            obj=d/'probe.obj';cmd=[cl]+flags+['/c',str(driver),'/Fo'+str(obj)]
            (d/'probe-command.json').write_text(json.dumps(cmd,indent=2))
            code,output=execute(cmd,project,env,d/'probe-compile.log')
            r['compile']=code;failed=bool(code)
            if code and mode=='stock' and platform=='x64' and (b'C4235' in output or b'C2485' in output):r['status']='expected-stock-x64-rejection'
            objects=[str(obj)]
            if not failed and struct.unpack('<H',obj.read_bytes()[:2])[0]!=machine:raise RuntimeError('wrong object architecture')
            if failed:continue
            libs=list(a.win32_library if platform=='Win32' else a.x64_library)
            if a.libraries_json:
                libs+=json.loads(a.libraries_json.read_text(encoding='utf-8-sig'))[config+'-'+platform]
            r['library_files']=[dict(path=x,sha256=digest(Path(x))) for x in libs if Path(x).is_file()]
            cmd=[link,'/nologo','/OPT:REF']+objects+libs+['/OUT:'+str(d/'probe.exe'),'/MAP:'+str(d/'probe.map')]
            if a.suppress_unused_stlport_autolink:cmd+=['/NODEFAULTLIB:stlport_vc71_static.lib','/NODEFAULTLIB:stlport_vc71_stldebug_static.lib']
            (d/'link-command.json').write_text(json.dumps(cmd,indent=2))
            code,output=execute(cmd,project,env,d/'link.log');r['link']=code
            if code:continue
            mapping=(d/'probe.map').read_text(errors='replace')
            if not any('?_fillVertexBufferHard_sse@@' in line and 'probe.obj' in line for line in mapping.splitlines()):raise RuntimeError('real skeletal kernel missing')
            binary=d/'records.bin';code,output=execute([str(d/'probe.exe'),str(binary)],project,env,d/'run.log',90);r['run']=code
            if code:continue
            data=binary.read_bytes();expected=(a.record_magic,a.record_version,a.expected_records,a.record_words)
            if len(data)!=16+a.expected_records*a.record_words*4 or struct.unpack_from('<4I',data)!=expected:
                r['record_failure']='wrong header or exact count';continue
            r.update(status='recorded',records_sha256=digest(binary),records=a.expected_records)
        (out/'results.json').write_text(json.dumps(dict(builds=results,comparisons=comparisons),indent=2))
for config in (a.configuration or ['Debug','Release']):
    directories={}
    for platform,mode in [('Win32','stock'),('Win32','candidate'),('x64','candidate')]:
        d=out/(config+'-'+platform+'-'+mode)
        if not any(r['name']==d.name and r['status']=='recorded' for r in results):break
        directories[platform+'-'+mode]=d
    else:
        unchanged=(directories['Win32-stock']/'records.bin').read_bytes()==(directories['Win32-candidate']/'records.bin').read_bytes()
        cmd=[sys.executable,str(comparator),str(directories['Win32-stock']/'records.bin'),str(directories['x64-candidate']/'records.bin')]
        code,output=execute(cmd,project,None,out/(config+'-comparison.json'),30)
        comparisons.append(dict(config=config,win32_records_unchanged=unchanged,comparison_exit=code,note='All recorded value/flag differences fail. Actual hard kernels called directly; rendering and dispatch not covered.'))
(out/'results.json').write_text(json.dumps(dict(builds=results,comparisons=comparisons),indent=2))
print(json.dumps(dict(builds=results,comparisons=comparisons)))
sys.exit(0 if len(comparisons)==len(a.configuration or ['Debug','Release']) and all(r['status'] in ['recorded','expected-stock-x64-rejection'] for r in results) and all(c['win32_records_unchanged'] and c['comparison_exit']==0 for c in comparisons) else 1)
