@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64 >nul
cd /d "C:\client-next-build\src\external\3rd\library\ui\build\win32"
cl /EHsc /MT /O2 /Gy /Y- /Zc:wchar_t- /nologo /D"NDEBUG" /D"_WINDOWS" /D"WIN32" /D"_LIB" /D"_CRT_SECURE_NO_DEPRECATE=1" /D"_VC80_UPGRADE=0x0600" /D"_MBCS" /I"C:/SDKs/DXSDK\Include" /I"..\..\..\..\..\ours\library\unicode\include" /I"..\..\..\directx9/include" /I"..\..\..\stlport453\stlport" /I"..\..\include\" /I"C:\client-next-build\src\external\3rd\library\ui\src\win32" C:/ui-output-probe.cpp /Fo"C:\ui-output-next\x64\probe.obj" /Fe"C:\ui-output-next\x64\probe.exe" /link "C:\client-next-build\src\compile\x64\ui\Release\ui.lib" /OPT:REF /OPT:ICF /MAP:"C:\ui-output-next\x64\probe.map" /VERBOSE:LIB
exit /b %errorlevel%
