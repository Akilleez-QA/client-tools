@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vcvarsall.bat" x86 >nul
cl /nologo /EHsc /DBODY_ONLY C:\memmove-rename-probe.cpp /Fo"C:\client-next-probes\x86-body-only.obj" /Fe"C:\client-next-probes\x86-body-only.exe"
exit /b %errorlevel%
