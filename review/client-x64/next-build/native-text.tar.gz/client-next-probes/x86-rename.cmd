@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vcvarsall.bat" x86 >nul
cl /nologo /EHsc  C:\memmove-rename-probe.cpp /Fo"C:\client-next-probes\x86-rename.obj" /Fe"C:\client-next-probes\x86-rename.exe"
exit /b %errorlevel%
