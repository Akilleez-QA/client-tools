@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vcvarsall.bat" amd64 >nul
cl /nologo /EHsc /DORIGINAL C:\memmove-rename-probe.cpp /Fo"C:\client-next-probes\amd64-original.obj" /Fe"C:\client-next-probes\amd64-original.exe"
exit /b %errorlevel%
