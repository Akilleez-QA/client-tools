@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vcvarsall.bat" x86
if errorlevel 1 exit /b 90
cd /d "C:\client-next-build\src\engine\shared\library\sharedMemoryManager\build\win32"
set CL=
set _CL_=
where cl
cl @"C:\memory-next\Release-Win32-candidate\compile.rsp"
exit /b %errorlevel%
