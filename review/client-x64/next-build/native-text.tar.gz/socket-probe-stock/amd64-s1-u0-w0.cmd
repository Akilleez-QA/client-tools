@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" amd64 >nul
cl /nologo /EHsc /W4 /DWIN32 /DSOCKET_PROBE_SOCK=1 /DSOCKET_PROBE_UDP=0 /DSOCKET_PROBE_WINSOCK_FIRST=0 /I"C:\ci-link-proof-clean\build-tree\src" /I"C:\ci-link-proof-clean\build-tree\src\engine\shared\library\sharedNetwork\include\public" /I"C:\ci-link-proof-clean\build-tree\src\external\3rd\library\soePlatform\VChatAPI\utils2.0\utils" C:/socket-probe.cpp /Fo"C:\socket-probe-stock\amd64-s1-u0-w0.obj" /Fe"C:\socket-probe-stock\amd64-s1-u0-w0.exe" /link Ws2_32.lib
exit /b %errorlevel%
