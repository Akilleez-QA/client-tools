@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio 12.0/VC/vcvarsall.bat" x86 >nul
cd /d "C:\client-next-build\src\external\3rd\library\ui\build\win32"
cl /EHsc /MT /O2 /Gy /Y- /Zc:wchar_t- /nologo /DNDEBUG /D_WINDOWS /DWIN32 /D_LIB /D_CRT_SECURE_NO_DEPRECATE=1 /D_VC80_UPGRADE=0x0600 /D_MBCS /I..\..\..\..\..\ours\library\unicode\include /I..\..\..\directx9/include /I..\..\..\stlport453\stlport /I..\..\include\ /IC:\client-next-build\src\external\3rd\library\ui\src\win32 C:/ui-output-probe.cpp /FoC:\ui-output-next-v2\Win32\probe.obj /FeC:\ui-output-next-v2\Win32\probe.exe /link C:\client-next-build\src\compile\win32\ui\Release\ui.lib /OPT:REF /OPT:ICF /MAP:C:\ui-output-next-v2\Win32\probe.map /VERBOSE:LIB
exit /b %errorlevel%
